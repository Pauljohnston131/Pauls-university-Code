public class Animal {
    private String food;
    private int lifeExpectancy;

    // Constructor with no parameters
    public Animal() {
        this.food = "Unknown";
        this.lifeExpectancy = 0;
    }

    // Constructor with only food parameter
    public Animal(String food) {
        this.food = food;
        this.lifeExpectancy = 0;
    }

    // Constructor with only life expectancy parameter
    public Animal(int lifeExpectancy) {
        this.food = "Unknown";
        this.lifeExpectancy = lifeExpectancy;
    }

    // Constructor with both food and life expectancy parameters
    public Animal(String food, int lifeExpectancy) {
        this.food = food;
        this.lifeExpectancy = lifeExpectancy;
    }

    // Getter and setter methods for food
    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    // Getter and setter methods for lifeExpectancy
    public int getLifeExpectancy() {
        return lifeExpectancy;
    }

    public void setLifeExpectancy(int lifeExpectancy) {
        this.lifeExpectancy = lifeExpectancy;
    }

    // toString method to describe the animal
    @Override
    public String toString() {
        return "This animal eats " + food + " and has an average life expectancy of " + lifeExpectancy + " years.";
    }

    public static void main(String[] args) {
        // Create 4 Animal objects with different constructors
        Animal animal1 = new Animal();
        Animal animal2 = new Animal("Meat");
        Animal animal3 = new Animal(10);
        Animal animal4 = new Animal("Fruit", 20);

        // Print descriptions of the animals
        System.out.println(animal1);
        System.out.println(animal2);
        System.out.println(animal3);
        System.out.println(animal4);
    }
}

class Lion extends Animal {
    private static int lionCount = 0;
    private int age;
    private String name;

    // Default constructor
    public Lion() {
        super("Meat", 15); // Default values for food and life expectancy
        this.age = 0;
        this.name = "Unknown";
        lionCount++;
    }

    // Constructor with parameters
    public Lion(String food, int lifeExpectancy, int age, String name) {
        super(food, lifeExpectancy);
        this.age = age;
        this.name = name;
        lionCount++;
    }

    // Setter for age
    public void setAge(int age) {
        this.age = age;
    }

    // toString method to describe the lion
    @Override
    public String toString() {
        return "This lion named " + name + " is " + age + " years old, eats " + getFood() + ", and has an average life expectancy of "
                + getLifeExpectancy() + " years.";
    }

    // Method to return the number of Lion objects created
    public static int numberOfLions() {
        return lionCount;
    }

    public static void main(String[] args) {
        Lion lion1 = new Lion("Meat", 15, 5, "Leo");
        Lion lion2 = new Lion("Meat", 15, 3, "Simba");

        // Print descriptions of the lions
        System.out.println(lion1);
        System.out.println(lion2);

        // Print the number of Lion objects created
        System.out.println("Number of Lion objects created: " + Lion.numberOfLions());
    }
}
