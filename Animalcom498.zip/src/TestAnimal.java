public class TestAnimal {
    public static void main(String[] args) {
        // Create two Lion objects with custom properties
        Lion myLion1 = new Lion("Meat", 15, 5, "Leo");
        Lion myLion2 = new Lion("Meat", 15, 3, "Simba");

        // Set the age of myLion1 to 3
        myLion1.setAge(3);

        // Print the details of myLion1 using the toString() method
        System.out.println("Details of myLion1:");
        System.out.println(myLion1);

        // Print the number of Lion objects created using the numberOfLions() method
        System.out.println("Number of Lion objects created: " + Lion.numberOfLions());
    }
}

