//import java.util.Stack;
//import java.util.LinkedList;

public class Thursday4 {

    public static void main(String[] args) {

        System.out.println("abccba ... " + is_a_palindrome("abccba"));
        System.out.println("abcdcba ... " + is_a_palindrome("abcdcba"));
        System.out.println("abccxa ... " + is_a_palindrome("abccxa"));
        System.out.println("abcdcxa ... " + is_a_palindrome("abcdcxa"));
        System.out.println("a ... " + is_a_palindrome("a"));
        System.out.println(" ... " + is_a_palindrome(""));

        generate_binary(8);
        generate_binary(16);
    }

    private static boolean is_a_palindrome(String str) {
        Stack<Character> stack = new Stack<Character>();
        boolean palindrome = true;
        int halfway = str.length() / 2;

        for (int i = 0; i < halfway; i++) {
            stack.push(str.charAt(i));
        }

        if (str.length() % 2 == 1) halfway = halfway + 1;

        for (int i = halfway; i < str.length(); i++) {
            if (!stack.pop().equals(str.charAt(i))) {
                palindrome = false;
            }
        }
        return palindrome;
    }

    private static void generate_binary(int n) {
        Queue<String> queue = new Queue<String>();
        // LinkedList<String> queue = new LinkedList<String>();
        queue.enqueue("1");                     // add() for the LinkedList class

        for (int i = 0; i < n; i++) {
            queue.enqueue(queue.getFront() + "0");  // add() and peek() for LinkedList class
            queue.enqueue(queue.getFront() + "1");
            System.out.print(queue.dequeue() + "   ");      // poll() for LinkedList class
        }
        System.out.println();
    }

}

