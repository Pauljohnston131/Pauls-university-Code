import java.util.Scanner;

public class Infix2Postfix {

    private static int precedence(char operator) {
        switch (operator) {
            case '^' : return 3;
            case '*': case '/' : return 2;
            case '+' : case '-' : return 1;
        }
        return 0;
    }

    public static String infix2postfix(String infix)
    {
        // initializing empty String for result
        String result = new String("");

        // initializing empty stack
        Stack<Character> stack = new Stack<Character>();

        // iterate across each character in the infix string
        for (int i = 0; i < infix.length(); i++)
        {
            char nextChar = infix.charAt(i);

            // If the scanned character is an operand (number), add it to output.
            if (Character.isDigit(nextChar))
                result = result + nextChar;

                // If the scanned character is an '(', push it to the stack.
            else if (nextChar == '(')
                stack.push(nextChar);

                //  If the scanned character is an ')', pop and output from the stack
                // until an '(' is encountered.
            else if (nextChar == ')')
            {
                while (stack.peek() != '(')
                    result = result + stack.pop();

                stack.pop(); // throw away the '(' that is now on top of the stack
            }
            else // an operator is encountered
            {
                // add to the output, every operator on the stack with a precedence greater than
                // or equal to the precedence of the operator found
                while (!stack.isEmpty() && precedence(nextChar) <= precedence(stack.peek())){
                    result = result + stack.pop();
                }
                stack.push(nextChar);
            }
        }

        // pop all the operators from the stack
        while (!stack.isEmpty()){
            result = result + stack.pop();
        }
        return result;
    }

    static int evaluatePostfix(String postfix)
    {
        //create a stack
        Stack<Integer> stack = new Stack<Integer>();

        // Scan all characters one by one
        for(int i = 0; i <postfix.length(); i++)
        {
            char nextChar = postfix.charAt(i);

            // If the scanned character is an operand (number here),
            // push it to the stack.
            if(Character.isDigit(nextChar))
                stack.push(nextChar - '0'); // convert the character into the equivalent integer

                //  If the scanned character is an operator, pop two
                // elements from stack apply the operator
            else
            {
                int val1 = stack.pop();
                int val2 = stack.pop();

                switch(nextChar)
                {
                    case '+':
                        stack.push(val2 + val1);
                        break;

                    case '-':
                        stack.push(val2 - val1);
                        break;

                    case '/':
                        stack.push(val2 / val1);
                        break;

                    case '*':
                        stack.push(val2 * val1);
                        break;

                    case '^':
                        stack.push((int)Math.pow(val2, val1));
                        break;
                }
            }
        }
        return stack.pop();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter an infix expression (no spaces) > ");
        String infix = input.nextLine();
        System.out.println("Postfix is :" + infix2postfix(infix));
        System.out.println("Result is " + evaluatePostfix(infix2postfix(infix)));
    }
}

