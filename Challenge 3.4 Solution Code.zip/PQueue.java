import java.util.Random;
import java.util.Arrays;

public class PQueue<T extends Comparable <T>> implements PQueueInterface<T> {

    /* Priority queue doesn't need the rear pointer as it is only needed in the normal enqueue operation */

    private MyNode<T> front;

    public PQueue() {
        front = null;
     }

    public void enqueue(T newEntry) {
        MyNode<T> newNode = new MyNode<T>(newEntry);
        if (front == null) front = newNode;
        else if (front.getData().compareTo(newEntry) < 0) {
            newNode.setNext(front);
            front = newNode;
        } else {
            MyNode<T> currentNode = front;
            while (currentNode.getNext() != null && currentNode.getNext().getData().compareTo(newEntry) > 0)
                currentNode = currentNode.getNext();
            newNode.setNext(currentNode.getNext());
            currentNode.setNext(newNode);
        }
    }

    public T dequeue() {
        // Java does not implement EmptyQueueExcecption
        if (front == null) return null;
        else {
            T valueToReturn = front.getData();
            front = front.getNext();
            return valueToReturn;
        }
    }

    public T getFront() {
        // Java does not implement EmptyQueueExcecption
        if (front == null) return null;
        else return front.getData();
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void clear() {
        front = null;
    }

    public static void main(String[] args) {
        PQueue<Integer> pQueue = new PQueue<Integer>();
        Random random = new Random();
        Integer[] randomValues = new Integer[10];

        for (int i = 0; i < randomValues.length; i++) {
            randomValues[i] = random.nextInt(1000);
            pQueue.enqueue(randomValues[i]);
        }
        System.out.println("Random array is " + Arrays.toString(randomValues));

        while (!pQueue.isEmpty()) {
            System.out.println("Removing value " + pQueue.dequeue());
        }
    }
}