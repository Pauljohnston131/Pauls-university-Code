public interface PQueueInterface<T> {

    public void enqueue(T newEntry);
    /* add a new entry to the pQueue in its priority position
       @param (T) newEntry - the new value to be added
    */

    public T dequeue();
    /* Return and remove the entry from the front of the queue
       Throw emptyQueueException if called on an empty queue
       @return (T) - the value of the front entry
    */

    public T getFront();
    /* Return but don't remove the entry from the front of the queue
       Throw emptyQueueException if called on an empty queue
       @return (T) - the value of the front entry
    */

    public boolean isEmpty();
    /* Check for an empty stack
       @return (boolean) - true if the queue is empty, false otherwise
     */

    public void clear();
    /* empty the queue  by removing all elements
     */
}