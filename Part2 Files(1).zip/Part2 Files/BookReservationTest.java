public class BookReservationTest {

    public static void main(String[] args) {
        // Create a book reservation system with a capacity of 3.
        BookReservation br = new BookReservation(3);

        System.out.print("Reserving 'Book 1'... ");
        System.out.println(br.reserveBook("Book 1"));

        System.out.print("Reserving 'Book 2'... ");
        System.out.println(br.reserveBook("Book 2"));

        System.out.print("Reserving 'Book 3'... ");
        System.out.println(br.reserveBook("Book 3"));

        System.out.print("Reserving 'Book 1'... ");
        System.out.println(br.reserveBook("Book 1"));

        System.out.print("Reserving 'Book 2'... ");
        System.out.println(br.reserveBook("Book 2"));

        System.out.print("Reserving 'Book 4'... ");
        System.out.println(br.reserveBook("Book 4"));

        System.out.print("Cancelling 'Book 3' reservation... ");
        System.out.println(br.cancelReservation("Book 3"));

        System.out.print("Cancelling 'Book 1' reservation... ");
        System.out.println(br.cancelReservation("Book 1"));

        System.out.print("Checking reservation for 'Book 2'...  ");
        System.out.println(br.isReserved("Book 2"));

        System.out.print("Checking reservation for 'Book 3'...  ");
        System.out.println(br.isReserved("Book 3"));

        System.out.print("Reserving 'Book 1'... ");
        System.out.println(br.reserveBook("Book 1"));

        System.out.print("Replacing reservation 'Book 4' with 'Book 3'... ");
        System.out.println(br.replaceReservation("Book 4", "Book 3"));

        System.out.print("Replacing reservation 'Book 2' with 'Book 1'... ");
        System.out.println(br.replaceReservation("Book 2", "Book 1"));

        System.out.print("Replacing reservation 'Book 1' with 'Book 5'... ");
        System.out.println(br.replaceReservation("Book 1", "Book 5"));

        System.out.println("In total, " + br.getTotalReserved() + " books have been reserved");

        System.out.println("Book Reservations: " + br.showAllReservations());
    }
}