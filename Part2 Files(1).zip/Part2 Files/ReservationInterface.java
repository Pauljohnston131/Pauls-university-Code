public interface ReservationInterface<T> {

    public int getCurrentSize();
    /* the number of elements currently contained in the reservation system

    @return - (int) number of elements
    */

    public boolean isEmpty();
    /* test for an empty reservation system

    @return - (boolean) true if the number of reservations is zero, false otherwise
    */

    public boolean makeReservation(T newReservation);
    /* test for spare capacity in the reservation system and if it exists, make a new reservation
    and increment the number of reservations

    @param (T) newReservation - the item to be reserved in the system

    @return - (boolean) true if the reservation is made, false otherwise
    */

    public T cancelReservation();
    /* cancel any reservation from the system, if one is available, and decrement the number
    of reservations. Return the canceled reservation or null if none is available

    @return - (T) the reservation that is canceled from the system, or null
    */

    public boolean cancelReservation(T reservation);
    /* cancel the specified reservation from the system, if it is present, and decrement
    the number of reservations

    @return - (boolean) true if the reservation is available, false otherwise
    */

    public void clear();
    /* clear the reservation system - set the number of reservations to zero
     */

    public int getFrequencyOf(T reservation);
    /* count how many times a given reservation appears in the system

    @param (T) reservation - the reservation to look for in the system

    @return - (int) the number of times that the given reservation appears
    */

    public boolean contains(T reservation);
    /* check for the presence of a specified reservation in the system

    @param (T) reservation - the reservation to look for in the system

    @return - (boolean) true if the system contains the reservation, false otherwise
    */

    public T[] toArray();
    /* find all reservations in the system

    @return - (T[]) an array of size number of reservations, containing all contents of the system
    */
}
