public final class ArrayReservation<T> implements ReservationInterface<T> {

    private T[] reservations;
    private int numberOfReservations;
    private static final int DEFAULT_CAPACITY = 25;
    private boolean initialized = false;
    private static final int MAX_CAPACITY = 10000;

    private boolean isArrayFull() {
        return (reservations.length == numberOfReservations);
    }

    private void checkInitialization() {
        if (!initialized)
            throw new SecurityException("ArrayReservation object is not initialized properly");
    }

    private T removeReservationAt(int index) {
        T result = null;
        if (!isEmpty() && index >= 0 && index < numberOfReservations) {
            result = reservations[index];
            reservations[index] = reservations[numberOfReservations - 1];
            reservations[numberOfReservations - 1] = null;
            numberOfReservations--;
        }
        return result;
    }

    public ArrayReservation() {
        this(DEFAULT_CAPACITY);
    }

    public ArrayReservation(int capacity) {
        if (capacity <= MAX_CAPACITY) {
            T[] tempReservations = (T[]) new Object[capacity];
            reservations = tempReservations;
            numberOfReservations = 0;
            initialized = true;
        } else throw new IllegalStateException("Attempt to create a reservation system where the capacity exceeds the maximum");
    }

    public int getCurrentSize() {
        return numberOfReservations;
    }

    public boolean isEmpty() {
        return (numberOfReservations == 0);
    }

    public boolean makeReservation(T newReservation) {
        checkInitialization();
        if (isArrayFull()) return false;
        else {
            reservations[numberOfReservations++] = newReservation;
            return true;
        }
    }

    public T cancelReservation() {
        checkInitialization();
        return removeReservationAt(numberOfReservations - 1);
    }

    public boolean cancelReservation(T reservation) {
        boolean found = false;
        int index = 0;
        while (!found && index < numberOfReservations)
            if (reservations[index].equals(reservation)) found = true;
            else index++;
        if (found) removeReservationAt(index);
        return found;
    }

    public void clear() {
        while (!isEmpty()) cancelReservation();
    }

    public int getFrequencyOf(T reservation) {
        int count = 0;
        for (int i = 0; i < numberOfReservations; i++)
            if (reservations[i].equals(reservation)) count++;
        return count;
    }

    public boolean contains(T reservation) {
        boolean found = false;
        int index = 0;
        while (!found && index < numberOfReservations)
            if (reservations[index++].equals(reservation)) found = true;
        return found;
    }

    public T[] toArray() {
        T[] resultArray = (T[]) new Object[numberOfReservations];
        System.arraycopy(reservations, 0, resultArray, 0, numberOfReservations);
        return resultArray;
    }

    public String toString() {
        String strResult = "Reservations [ ";
        for (int i = 0; i < numberOfReservations; i++)
            strResult += reservations[i] + " ";
        strResult += "]";
        return strResult;
    }

//    public static void main(String[] args) {
//        ArrayReservation<String> reservationSystem = new ArrayReservation<String>(5);
//
//        System.out.println("Making Reservation for Alice... " + reservationSystem.makeReservation("Alice"));
//        System.out.println("Making Reservation for Bob... " + reservationSystem.makeReservation("Bob"));
//        System.out.println("Making Reservation for Carol... " + reservationSystem.makeReservation("Carol"));
//
//        Object[] arrayOfReservations = reservationSystem.toArray();
//        for (Object name : arrayOfReservations) System.out.print(name + "...");
//        System.out.println();
//
//        System.out.println("Making Reservation for Dave... " + reservationSystem.makeReservation("Dave"));
//        System.out.println("Making Reservation for Eve... " + reservationSystem.makeReservation("Eve"));
//        System.out.println("Making Reservation for Frank... " + reservationSystem.makeReservation("Frank"));
//
//        Object[] arrayOfReservations2 = reservationSystem.toArray();
//        for (Object name : arrayOfReservations2) System.out.print(name + "...");
//        System.out.println();
//    }
}
