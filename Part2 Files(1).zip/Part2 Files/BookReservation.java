public class BookReservation {

    private ArrayReservation<String> slots;
    private int totalReserved = 0;

    public BookReservation(int size) {
        this.slots = new ArrayReservation<String>(3); // Adjust the size accordingly.
    }

    public String showAllReservations() {
        return slots.toString();
    }

    public boolean reserveBook(String title) {
        // Modify this method to allow each book title to be reserved only once.
        // Return false if a duplicate title is presented.
        return this.slots.makeReservation(title);

    }

    public boolean cancelReservation(String title) {
        // Remove the reservation matching the provided title as a parameter.
        // Return false if the operation cannot be completed.
        return true; // modify this line if required
    }

    public boolean isReserved(String title) {
        // Return true if a book matching the title provided as a parameter is reserved.
        // Return false otherwise.
        return true; //modify this line if required
    }

    public boolean replaceReservation(String cancelTitle, String reserveTitle) {
        // Replace the book reservation matching "cancelTitle" with the book matching "reserveTitle".
        // Return true if the operation can be successfully completed, false otherwise.

        return true; //modify this line if required
    }

    public int getTotalReserved() {
        // Use the instance variable "totalReserved" to keep a count of all book titles reserved.

        //Note: You SHOULD NOT NEED TO CHANGE THIS METHOD
        return this.totalReserved;
    }
}
